export interface Content {
  id: number;
  title: string;
  description: string;
  prize: string;
  imgURL: string;
  type: string;
  tags: string[];
}
