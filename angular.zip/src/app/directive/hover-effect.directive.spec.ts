import { HoverEffectDirective } from './hover-effect.directive';

describe('HoverEffectDirective', () => {
  it('should create an instance', () => {
    const directive = new HoverEffectDirective();
    expect(directive).toBeTruthy();
  });
});
