import { BorderDirective } from './border.directive';

describe('BorderDirective', () => {
  it('should create an instance', () => {
    const directive = new BorderDirective();
    expect(directive).toBeTruthy();
  });
});
