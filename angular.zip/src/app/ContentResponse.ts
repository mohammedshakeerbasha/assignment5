export interface ContentResponse {
  status: boolean;
  msg: string;
}
